
// ---------- Завдання 1 ----------
interface Animal {
    name: string;
    canFly?: boolean;
    canSwim?: boolean;
    move(): void;
}

class Cat implements Animal {
    name: string;
    constructor(name: string) { this.name = name; }
    move(): void { console.log(`${this.name} рухається на лапах`); }
}

class Bird implements Animal {
    name: string;
    canFly = true;
    constructor(name: string) { this.name = name; }
    move(): void { console.log(`${this.name} летить`); }
}

class Fish implements Animal {
    name: string;
    canSwim = true;
    constructor(name: string) { this.name = name; }
    move(): void { console.log(`${this.name} пливе`); }
}

const animals: Animal[] = [
    new Cat("Мурчик"),
    new Bird("Синичка"),
    new Fish("Золота рибка")
];
animals.forEach(a => a.move());

// ---------- Завдання 2 ----------
interface Shape {
    getArea(): number;
    getPerimeter(): number;
    scale(factor: number): void;
}

class Circle implements Shape {
    constructor(public radius: number) {}
    getArea(): number { return Math.PI * this.radius ** 2; }
    getPerimeter(): number { return 2 * Math.PI * this.radius; }
    scale(factor: number): void { this.radius *= factor; }
}

class Rectangle implements Shape {
    constructor(public width: number, public height: number) {}
    getArea(): number { return this.width * this.height; }
    getPerimeter(): number { return 2 * (this.width + this.height); }
    scale(factor: number): void {
        this.width *= factor; this.height *= factor;
    }
}

class Triangle implements Shape {
    constructor(public a: number, public b: number, public c: number) {}
    getArea(): number {
        const p = this.getPerimeter() / 2;
        return Math.sqrt(p * (p - this.a) * (p - this.b) * (p - this.c));
    }
    getPerimeter(): number { return this.a + this.b + this.c; }
    scale(factor: number): void {
        this.a *= factor; this.b *= factor; this.c *= factor;
    }
}

const shapes: Shape[] = [
    new Circle(5),
    new Rectangle(4, 6),
    new Triangle(3, 4, 5)
];
let totalArea = 0, totalPerimeter = 0;
shapes.forEach(s => {
    totalArea += s.getArea();
    totalPerimeter += s.getPerimeter();
});
console.log("Загальна площа:", totalArea);
console.log("Загальний периметр:", totalPerimeter);

// ---------- Завдання 3 ----------
abstract class Car {
    constructor(
        protected brand: string,
        protected model: string,
        private year: number
    ) {}
    abstract showInfo(): void;
}

class Tesla extends Car {
    constructor(model: string, year: number, public battery: number) {
        super("Tesla", model, year);
    }
    showInfo(): void { console.log(`Tesla ${this.model}, батарея: ${this.battery} кВт`); }
}

class BMW extends Car {
    constructor(model: string, year: number, public engine: string) {
        super("BMW", model, year);
    }
    showInfo(): void { console.log(`BMW ${this.model}, двигун: ${this.engine}`); }
}

class Toyota extends Car {
    constructor(model: string, year: number, public fuelType: string) {
        super("Toyota", model, year);
    }
    showInfo(): void { console.log(`Toyota ${this.model}, паливо: ${this.fuelType}`); }
}

const cars: Car[] = [
    new Tesla("Model S", 2022, 100),
    new Tesla("Model 3", 2023, 75),
    new BMW("X5", 2020, "V8"),
    new BMW("M3", 2021, "V6"),
    new Toyota("Corolla", 2019, "Petrol"),
    new Toyota("Prius", 2022, "Hybrid"),
];
cars.forEach(c => c.showInfo());

// ---------- Завдання 4 ----------
interface Payable { pay(): void; }

abstract class Employee {
    constructor(public name: string, public age: number, public salary: number) {}
    abstract getAnnualBonus(): number;
}

class Developer extends Employee implements Payable {
    getAnnualBonus(): number { return this.salary * 0.1; }
    pay(): void { console.log(`${this.name} отримав зарплату ${this.salary}`); }
}

class Manager extends Employee implements Payable {
    getAnnualBonus(): number { return this.salary * 0.2; }
    pay(): void { console.log(`${this.name} отримав зарплату ${this.salary}`); }
}

const employees: Employee[] = [
    new Developer("Іван", 25, 3000),
    new Developer("Марія", 28, 3500),
    new Manager("Олег", 40, 5000),
];
let totalBonus = 0;
employees.forEach(e => totalBonus += e.getAnnualBonus());
console.log("Загальна річна сума бонусів:", totalBonus);

// ---------- Завдання 5 ----------
interface Course {
    name: string;
    duration: number;
    students: string[];
}

class OnlineCourse implements Course {
    students: string[] = [];
    constructor(public name: string, public duration: number) {}
    registerStudent(student: string): void {
        if (!this.isStudentRegistered(student)) this.students.push(student);
    }
    isStudentRegistered(student: string): boolean {
        return this.students.includes(student);
    }
}

class CourseManager {
    private courses: Course[] = [];
    addCourse(course: Course): void { this.courses.push(course); }
    removeCourse(courseName: string): void {
        this.courses = this.courses.filter(c => c.name !== courseName);
    }
    findCourse(courseName: string): Course | undefined {
        return this.courses.find(c => c.name === courseName);
    }
    listCourses(): void {
        this.courses.forEach(c => console.log(`${c.name} (${c.duration} год): [${c.students.join(", ")}]`));
    }
}

const cm = new CourseManager();
const ts = new OnlineCourse("TypeScript", 30);
const js = new OnlineCourse("JavaScript", 25);
cm.addCourse(ts); cm.addCourse(js);
ts.registerStudent("Аня");
ts.registerStudent("Ігор");
js.registerStudent("Оля");
cm.listCourses();

// ---------- Завдання 6 ----------
interface LibraryItem {
    title: string;
    author: string;
    borrow(): void;
}

class Book implements LibraryItem {
    constructor(public title: string, public author: string, public pages: number) {}
    borrow(): void { console.log(`Книга "${this.title}" позичена`); }
}

class Magazine implements LibraryItem {
    constructor(public title: string, public author: string, public issue: number) {}
    borrow(): void { console.log(`Журнал "${this.title}" №${this.issue} позичений`); }
}

class DVD implements LibraryItem {
    constructor(public title: string, public author: string, public duration: number) {}
    borrow(): void { console.log(`DVD "${this.title}" тривалістю ${this.duration} хв позичений`); }
}

class Library {
    private items: LibraryItem[] = [];
    addItem(item: LibraryItem): void { this.items.push(item); }
    findItemByName(name: string): LibraryItem | undefined {
        return this.items.find(i => i.title === name);
    }
    listItems(): void { this.items.forEach(i => console.log(`${i.title} — ${i.author}`)); }
}

const lib = new Library();
lib.addItem(new Book("1984", "Дж. Орвелл", 328));
lib.addItem(new Magazine("Forbes", "Редакція", 202));
lib.addItem(new DVD("Inception", "К. Нолан", 148));
lib.listItems();
lib.findItemByName("1984")?.borrow();
